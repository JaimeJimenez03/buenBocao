package com.buenbocao.api.social.service;

import com.buenbocao.api.common.constants.AppConstants;
import com.buenbocao.api.common.exception.BusinessException;
import com.buenbocao.api.common.exception.ResourceNotFoundException;
import com.buenbocao.api.common.response.PagedResponse;
import com.buenbocao.api.notification.service.NotificationService;
import com.buenbocao.api.recipe.dto.response.RecipeCardResponse;
import com.buenbocao.api.recipe.entity.Recipe;
import com.buenbocao.api.recipe.mapper.RecipeMapper;
import com.buenbocao.api.recipe.repository.RecipeRepository;
import com.buenbocao.api.security.CustomUserDetails;
import com.buenbocao.api.social.entity.Favorite;
import com.buenbocao.api.social.repository.FavoriteRepository;
import com.buenbocao.api.user.entity.User;
import com.buenbocao.api.user.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Servicio de favoritos.
 * Permite añadir, quitar y listar recetas favoritas.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class FavoriteService {

    private final FavoriteRepository favoriteRepository;
    private final RecipeRepository recipeRepository;
    private final UserRepository userRepository;
    private final RecipeMapper recipeMapper;
    private final NotificationService notificationService;

    /**
     * Añade una receta a favoritos. Si ya está, la quita (toggle).
     * Devuelve true si se añadió, false si se eliminó.
     */
    @Transactional
    public boolean toggleFavorite(CustomUserDetails currentUser, Long recipeId) {
        Recipe recipe = recipeRepository.findById(recipeId)
                .orElseThrow(() -> new ResourceNotFoundException("Receta", "id", recipeId));

        boolean exists = favoriteRepository.existsByUserIdAndRecipeId(currentUser.getId(), recipeId);

        if (exists) {
            favoriteRepository.deleteByUserIdAndRecipeId(currentUser.getId(), recipeId);
            return false;
        } else {
            User user = userRepository.findById(currentUser.getId())
                    .orElseThrow(() -> new ResourceNotFoundException("Usuario", "id", currentUser.getId()));

            Favorite favorite = Favorite.builder()
                    .user(user)
                    .recipe(recipe)
                    .build();

            favoriteRepository.save(favorite);

            notificationService.notifyNewFavorite(
                    user.getId(),
                    recipe.getAuthor().getId(),
                    recipe.getId(),
                    recipe.getTitle());

            return true;
        }
    }

    /**
     * Lista las recetas favoritas del usuario autenticado.
     */
    @Transactional(readOnly = true)
    public PagedResponse<RecipeCardResponse> getMyFavorites(CustomUserDetails currentUser, int page, int size) {
        size = Math.min(size, AppConstants.MAX_PAGE_SIZE);
        Pageable pageable = PageRequest.of(page, size);

        Page<Favorite> favoritesPage = favoriteRepository
                .findByUserIdOrderByCreatedAtDesc(currentUser.getId(), pageable);

        List<RecipeCardResponse> content = favoritesPage.getContent().stream()
                .map(fav -> recipeMapper.toCardResponse(fav.getRecipe()))
                .toList();

        return PagedResponse.of(favoritesPage, content);
    }

    /**
     * Comprueba si el usuario actual tiene una receta en favoritos.
     */
    @Transactional(readOnly = true)
    public boolean isFavorite(Long userId, Long recipeId) {
        return favoriteRepository.existsByUserIdAndRecipeId(userId, recipeId);
    }

    /**
     * Cuenta cuántos usuarios han guardado una receta en favoritos.
     */
    @Transactional(readOnly = true)
    public long countFavorites(Long recipeId) {
        return favoriteRepository.countByRecipeId(recipeId);
    }
}
