package com.buenbocao.api.social.repository;

import com.buenbocao.api.social.entity.Favorite;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * Repositorio para la entidad Favorite.
 */
@Repository
public interface FavoriteRepository extends JpaRepository<Favorite, Long> {

    Optional<Favorite> findByUserIdAndRecipeId(Long userId, Long recipeId);

    boolean existsByUserIdAndRecipeId(Long userId, Long recipeId);

    /**
     * Lista los favoritos de un usuario (ordenados por fecha, los más recientes
     * primero).
     */
    Page<Favorite> findByUserIdOrderByCreatedAtDesc(Long userId, Pageable pageable);

    /**
     * Cuenta cuántos usuarios han guardado una receta en favoritos.
     */
    long countByRecipeId(Long recipeId);

    void deleteByUserIdAndRecipeId(Long userId, Long recipeId);

    @Query("SELECT f.recipe.id, COUNT(f) FROM Favorite f WHERE f.recipe.id IN :recipeIds GROUP BY f.recipe.id")
    List<Object[]> countFavoritesForRecipes(@Param("recipeIds") Set<Long> recipeIds);
}
